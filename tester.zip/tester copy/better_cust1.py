#changes made:
    # screens imp. as func.
    # only shows the selected car in the middle
    # better car selection background - made with ai

### example screen function from github repo:
def example_screen_function():
    #this opens a window with the color grey and names it
    pygame.display.set_caption("Kar Kart")
    screen.fill((30, 30, 30))
###


import pygame
import sys

pygame.init()

#colors
WHITE = (255, 255, 255)
YELLOW = (195, 93, 2)
YELL_H = (253, 177, 0)

#globals/constants
WIDTH, HEIGHT = 800, 600
w, h = WIDTH, HEIGHT

#font
font = pygame.font.SysFont(None, 36) # None -> default pygame font, 36->font size

#screen setup
clock = pygame.time.Clock()
screen = pygame.display.set_mode((800, 600))

# load all images together
background = pygame.transform.scale(pygame.image.load("start.png").convert(), (WIDTH, HEIGHT))
background2 = pygame.transform.scale(pygame.image.load("cust1.png").convert(), (WIDTH, HEIGHT))
car1_img = pygame.transform.scale(pygame.image.load("amv.png").convert_alpha(), (360, 183))
car2_img = pygame.transform.scale(pygame.image.load("ja.png").convert_alpha(), (360, 261))
car3_img = pygame.transform.scale(pygame.image.load("tm.png").convert_alpha(), (360, 129))   

#music 
pygame.mixer.init()
pygame.mixer.music.load("song.mp3")
pygame.mixer.music.set_volume(0.7)
pygame.mixer.music.play(-1) # music will loop indefinitely



###################-START SCREEN FUNCTION-#######################
def start_screen():
    pygame.display.set_caption("Start Screen")

    # display start screen background
    screen.blit(background, (0, 0))   # just use it directly

    # START button properties
    # Render the text - creates a surface like image - what the text looks like()
    text_surface = font.render("PLAY", True, (WHITE)) # "START" = the text, True = anti-aliasing (smooth edges), color

    button_rect = pygame.Rect(320, 515, 160, 40) # Rect stores: width / height, position (x, y)
    button_color = YELLOW
    hover_color = YELL_H

    # text_rect: where the text is placed 
    text_rect = text_surface.get_rect(center = button_rect.center) # center the text inside the button


    ### draw everything(in start screen) -order matters! ###
    #    
    # draw(blit) BACKGROUND
    screen.blit(background, (0, 0))
    # HOVER effect
    mouse_pos = pygame.mouse.get_pos()
    color = hover_color if button_rect.collidepoint(mouse_pos) else button_color
    # draw start BUTTON
    pygame.draw.rect(screen, color, button_rect)
    # draw 'play'' TEXT on the button
    screen.blit(text_surface, text_rect)

    # returns button_rect to check clicks in main() --> for navigation to next screen
    return button_rect

###################-CUST 1 SCREEN FUNCTION-#######################
def cust1_screen(selected):
    pygame.display.set_caption("Customization Screen 1")


    # draw background first, then cars on top
    screen.blit(background2, (0, 0))

    # all car images in list to index them
    car_images = [car1_img, car2_img, car3_img]

    # display only selected car in the center
    center_pos = (w//2 - car_images[selected].get_width()//2, h//2 - car_images[selected].get_height()//2)
    screen.blit(car_images[selected], center_pos)

    return selected


def main():
    game_state = "start"
    selected = 1
    running = True
    start_btn = None    # placeholder until start_screen() runs

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                if game_state == "start" and start_btn:
                    if start_btn.collidepoint(event.pos):
                        game_state = "customization1"

            if event.type == pygame.KEYDOWN:
                if game_state == "customization1":
                    if event.key == pygame.K_RIGHT:
                        selected = min(2, selected + 1)
                    elif event.key == pygame.K_LEFT:
                        selected = max(0, selected - 1)

        # Draw current screen
        if game_state == "start":
            start_btn = start_screen()
        elif game_state == "customization1":
            cust1_screen(selected)

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()



if __name__ == "__main__":
    main()




############################# Complete - Improve ############################# 

# TO DO:   
    # BACK and NEXT buttons: navigate between the screens 
    # SETTINGS/MENU button: audio(switch on/off) - difficulty(x3)

# NOW I NEED:
    # CARS to select: images(x3) - real ones or at least similar car images
    # MUSIC to play in background: .mp3  -free copyright

# NAME of the game: choose. 
    # --> 'Ultra Speed' for example.

#xtras
    # modify/remove 'car features/statistics' (on Customization Screen 1) ??
    
    # would be great if car image has reflection on the floor (:

#############################        ---         #############################